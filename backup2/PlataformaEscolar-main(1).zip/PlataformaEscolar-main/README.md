# PlataformaEscolar
Plataforma Escolar para alumnos, profesores, docentes y directivos
